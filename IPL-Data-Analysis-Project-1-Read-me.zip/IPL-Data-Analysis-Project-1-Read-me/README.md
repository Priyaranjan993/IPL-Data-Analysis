This Project Based in IPL Data.
Excel based project.
Using some  Data Cleaning and Validation process in Power query editor.
Make the relationship and created data view,Report view and table view.
Its basically summarized the IPL team wise tota run.
total number innings played in one year .
created some masure and some calculated column using of DAX function.
Showes the indivusual contribution of each and each batmans.
 created a total number of  venue.
 
 
 
 ![image](https://user-images.githubusercontent.com/72062824/161097138-9877c68a-c2f5-4ee9-a97c-54ae3cb17159.png)

 

